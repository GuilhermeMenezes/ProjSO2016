#include "cmd.h"
#include "buffer.h"
#include "includes.h"
#include <stdio.h>

void *worker(void *arg) {
	while (1) {
		comando_t executa;
		executa = buff_pop();


		if (executa.operacao == OP_DEBITAR) {
			if (debitar(executa.idConta, executa.valor) < 0) {
				printf("%s(%d, %d): Erro\n\n", COMANDO_DEBITAR, executa.idConta,
						executa.valor);
			} else
				printf("%s(%d, %d): OK\n\n", COMANDO_DEBITAR, executa.idConta,
						executa.valor);
		}
		if (executa.operacao == OP_CREDITAR) {
			if (creditar(executa.idConta, executa.valor) < 0)
				printf("%s(%d, %d): Erro\n\n", COMANDO_CREDITAR,
						executa.idConta, executa.valor);
			else
				printf("%s(%d, %d): OK\n\n", COMANDO_CREDITAR, executa.idConta,
						executa.valor);

		}
		if (executa.operacao == OP_LERSALDO) {
			if (lerSaldo(executa.idConta) < 0)
				printf("%s(%d): Erro.\n\n", COMANDO_LER_SALDO, executa.idConta);
			else
				printf("%s(%d): O saldo da conta é %d.\n\n", COMANDO_LER_SALDO,
						executa.idConta, lerSaldo(executa.idConta));
		}
		if (executa.operacao == OP_SAIR) {

			pthread_exit(NULL);

		}



	}
}
