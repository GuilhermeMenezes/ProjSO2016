#include "cmd.h"

void buff_insert(comando_t cmd);
comando_t buff_pop();
